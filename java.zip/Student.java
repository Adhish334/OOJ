package CIE;

public class Student {
    public String usn, name;
    public int sem;
}
