package CIE;

public class Internals extends Student {
    public int[] internalMarks = new int[5];
}